package com.dabigjoe.obsidianOverhaul;

import com.dabigjoe.obsidianAPI.event.AnimationEvent;
import com.dabigjoe.obsidianAPI.event.AnimationEvent.AnimationEventType;
import com.dabigjoe.obsidianAPI.event.AnimationEventListener;
import com.example.examplemod.EntityRingTailedLemur;

public class AnimationEventHandler {
	
}