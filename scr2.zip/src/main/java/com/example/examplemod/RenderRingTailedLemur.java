package com.example.examplemod;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;



public class RenderRingTailedLemur extends RenderLiving
{
	   public RenderRingTailedLemur(RenderManager p_i46187_1_, ModelBase p_i46187_2_, float p_i46187_3_)
	    {
	        super(p_i46187_1_, p_i46187_2_, p_i46187_3_);
	    }
	private static final RenderManager RenderManager = null;
	protected ResourceLocation hyenaTexture;
	
    public RenderRingTailedLemur(RenderManager p_i47196_1_, ModelChinchilla chinchilla, float f)
    {
        super(p_i47196_1_, new ModelChinchilla(), 0.3F);
    }
    
	 public static ResourceLocation texture = new ResourceLocation("de" + ":" + "textures/entity/preyanimal/ringtailedlemur.png");


	    protected ResourceLocation getEntityTexture(EntityRingTailedLemur entity)
	    {
	        switch (entity.getTameSkin())
	        {
	      case 0: 
	      default: 
	        return texture;
	      case 1: 
	        return texture;
	      case 2: 
	        return texture;
	      case 3: 
	        return texture;
	      case 4: 
	        return texture;
	      case 5: 
	        return texture;
	      case 6:
	        return texture;
	    }
}

		@Override
		protected ResourceLocation getEntityTexture(Entity entity) {
			// TODO Auto-generated method stub
			return texture;
		}
}
