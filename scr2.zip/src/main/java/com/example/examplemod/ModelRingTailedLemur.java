package com.example.examplemod;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelParrot;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityParrot;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * RingTailedLemur - Undefined
 * Created using Tabula 5.1.0
 */
public class ModelRingTailedLemur extends ModelBase {
    public ModelRenderer shape1;
    public ModelRenderer shape1_1;
    public ModelRenderer shape1_2;
    public ModelRenderer shape1_3;
    public ModelRenderer leg2;
    public ModelRenderer leg1;
    public ModelRenderer leg2_1;
    public ModelRenderer leg2_2;
    public ModelRenderer shape24;
    public ModelRenderer shape1_4;
    public ModelRenderer shape1_5;
    public ModelRenderer shape1_6;
    public ModelRenderer shape8;
    public ModelRenderer shape8_1;
    public ModelRenderer shape8_2;
    public ModelRenderer shape8_3;
    public ModelRenderer shape8_4;
    public ModelRenderer shape8_5;
    public ModelRenderer shape8_6;
    public ModelRenderer shape8_7;
    public ModelRenderer shape8_8;
    public ModelRenderer shape8_9;
    public ModelRenderer shape8_10;
    public ModelRenderer shape8_11;
    public ModelRenderer shape24_1;
    public ModelRenderer shape24_2;
    public ModelRenderer shape28;
    public ModelRenderer shape28_1;
    public ModelRenderer shape24_3; 

    public ModelRingTailedLemur() {
        this.textureWidth = 100;
        this.textureHeight = 100;
        this.shape8_1 = new ModelRenderer(this, 0, 27);
        this.shape8_1.setRotationPoint(0.0F, 4.4F, 0.8F);
        this.shape8_1.addBox(0.0F, 0.0F, 0.0F, 3, 6, 3, 0.0F);
        this.setRotateAngle(shape8_1, 0.091106186954104F, 0.0F, 0.0F);
        this.shape1_1 = new ModelRenderer(this, 0, 27);
        this.shape1_1.setRotationPoint(-6.0F, 0.2F, 0.0F);
        this.shape1_1.addBox(-2.0F, -0.2F, -0.1F, 9, 9, 8, 0.0F);
        this.shape1 = new ModelRenderer(this, 0, 27);
        this.shape1.setRotationPoint(-4.0F, 5.0F, 2.0F);
        this.shape1.addBox(1.0F, 0.0F, -0.1F, 6, 9, 8, 0.0F);
        this.setRotateAngle(shape1, 0.0F, 1.593485607070823F, 0.0F);
        this.shape8_2 = new ModelRenderer(this, 0, 82);
        this.shape8_2.setRotationPoint(0.0F, 4.0F, 0.0F);
        this.shape8_2.addBox(0.0F, 0.0F, 0.0F, 3, 2, 5, 0.0F);
        this.shape8_5 = new ModelRenderer(this, 0, 82);
        this.shape8_5.setRotationPoint(0.0F, 4.0F, 0.0F);
        this.shape8_5.addBox(0.0F, 0.0F, 0.0F, 3, 2, 5, 0.0F);
        this.shape8 = new ModelRenderer(this, 0, 27);
        this.shape8.setRotationPoint(0.0F, 5.0F, 0.0F);
        this.shape8.addBox(0.0F, 0.0F, 0.0F, 3, 6, 4, 0.0F);
        this.setRotateAngle(shape8, 0.22759093446006054F, 0.0F, 0.0F);
        this.shape28_1 = new ModelRenderer(this, 40, 26);
        this.shape28_1.setRotationPoint(5.8F, 0.1F, 3.3F);
        this.shape28_1.addBox(-0.4F, 1.2F, 0.0F, 4, 1, 3, 0.0F);
        this.setRotateAngle(shape28_1, 0.0F, -0.5009094953223726F, 0.0F);
        this.leg2_1 = new ModelRenderer(this, 0, 27);
        this.leg2_1.setRotationPoint(7.6F, 3.7F, 2.0F);
        this.leg2_1.addBox(0.0F, 0.0F, 0.0F, 3, 6, 5, 0.0F);
        this.setRotateAngle(leg2_1, -0.091106186954104F, 1.5481070465189704F, 0.0F);
        this.shape1_2 = new ModelRenderer(this, 0, 27);
        this.shape1_2.setRotationPoint(5.0F, 0.0F, 0.0F);
        this.shape1_2.addBox(0.0F, 0.0F, -0.1F, 7, 9, 8, 0.0F);
        this.setRotateAngle(shape1_2, 0.0F, 0.0F, -0.18203784098300857F);
        this.shape1_4 = new ModelRenderer(this, 0, 0);
        this.shape1_4.setRotationPoint(-0.1F, 9.0F, 0.0F);
        this.shape1_4.addBox(0.0F, 0.0F, 0.0F, 4, 10, 4, 0.0F);
        this.setRotateAngle(shape1_4, -0.045553093477052F, 0.0F, -0.091106186954104F);
        this.shape8_8 = new ModelRenderer(this, 0, 82);
        this.shape8_8.setRotationPoint(0.0F, 4.0F, 0.0F);
        this.shape8_8.addBox(0.0F, -0.2F, 0.0F, 3, 2, 5, 0.0F);
        this.setRotateAngle(shape8_8, 0.045553093477052F, 0.0F, 0.0F);
        this.shape8_4 = new ModelRenderer(this, 0, 27);
        this.shape8_4.setRotationPoint(0.0F, 4.4F, 0.8F);
        this.shape8_4.addBox(0.0F, 0.0F, 0.0F, 3, 6, 3, 0.0F);
        this.setRotateAngle(shape8_4, 0.091106186954104F, 0.0F, 0.0F);
        this.shape8_10 = new ModelRenderer(this, 0, 27);
        this.shape8_10.setRotationPoint(0.0F, 4.4F, 0.6F);
        this.shape8_10.addBox(0.0F, -0.4F, 0.0F, 3, 6, 3, 0.0F);
        this.setRotateAngle(shape8_10, -0.045553093477052F, 0.0F, 0.0F);
        this.shape24_3 = new ModelRenderer(this, 0, 58);
        this.shape24_3.setRotationPoint(2.9F, -0.4F, 0.0F);
        this.shape24_3.addBox(0.0F, 0.0F, 0.0F, 3, 9, 3, 0.0F);
        this.setRotateAngle(shape24_3, 0.0F, 0.0F, 0.27314402793711257F);
        this.shape1_3 = new ModelRenderer(this, 0, 0);
        this.shape1_3.setRotationPoint(-4.0F, 1.0F, 2.0F);
        this.shape1_3.addBox(0.0F, 0.0F, 0.0F, 4, 10, 4, 0.0F);
        this.setRotateAngle(shape1_3, 0.045553093477052F, 0.0F, 2.6862362517444724F);
        this.shape28 = new ModelRenderer(this, 40, 26);
        this.shape28.setRotationPoint(4.0F, 1.6F, -0.1F);
        this.shape28.addBox(0.0F, 0.0F, 0.0F, 4, 1, 3, 0.0F);
        this.setRotateAngle(shape28, 0.091106186954104F, 0.4553564018453205F, -0.045553093477052F);
        this.shape8_3 = new ModelRenderer(this, 0, 27);
        this.shape8_3.setRotationPoint(0.0F, 5.0F, 0.0F);
        this.shape8_3.addBox(0.0F, 0.0F, 0.0F, 3, 6, 4, 0.0F);
        this.setRotateAngle(shape8_3, 0.31869712141416456F, 0.0F, 0.0F);
        this.shape24_1 = new ModelRenderer(this, 29, 0);
        this.shape24_1.setRotationPoint(2.4F, 3.7F, 0.0F);
        this.shape24_1.addBox(0.0F, 0.0F, 0.0F, 6, 6, 6, 0.0F);
        this.setRotateAngle(shape24_1, 0.0F, 0.0F, 0.6373942428283291F);
        this.leg1 = new ModelRenderer(this, 0, 27);
        this.leg1.setRotationPoint(-5.9F, 4.0F, 8.5F);
        this.leg1.addBox(0.0F, 0.0F, 0.0F, 3, 6, 5, 0.0F);
        this.setRotateAngle(leg1, -0.4553564018453205F, 1.5481070465189704F, 0.0F);
        this.leg2_2 = new ModelRenderer(this, 0, 27);
        this.leg2_2.setRotationPoint(7.0F, 4.0F, 9.0F);
        this.leg2_2.addBox(0.0F, 0.0F, 0.0F, 3, 6, 5, 0.0F);
        this.setRotateAngle(leg2_2, 0.0F, 1.6845917940249266F, 0.0F);
        this.shape1_6 = new ModelRenderer(this, 0, 0);
        this.shape1_6.setRotationPoint(0.0F, 7.0F, 0.0F);
        this.shape1_6.addBox(0.0F, 0.0F, 0.0F, 4, 5, 4, 0.0F);
        this.setRotateAngle(shape1_6, 0.0F, 0.0F, -0.40980330836826856F);
        this.shape24_2 = new ModelRenderer(this, 0, 58);
        this.shape24_2.setRotationPoint(0.0F, 1.0F, 1.6F);
        this.shape24_2.addBox(0.5F, -0.6F, 0.0F, 2, 9, 3, 0.0F);
        this.setRotateAngle(shape24_2, -0.045553093477052F, 0.0F, 0.0F);
        this.shape24 = new ModelRenderer(this, 0, 27);
        this.shape24.setRotationPoint(10.0F, 5.9F, 0.8F);
        this.shape24.addBox(0.0F, 0.0F, 0.0F, 6, 7, 6, 0.0F);
        this.setRotateAngle(shape24, 0.0F, 0.0F, -2.1855012893472994F);
        this.leg2 = new ModelRenderer(this, 0, 27);
        this.leg2.setRotationPoint(-6.0F, 4.0F, 2.4F);
        this.leg2.addBox(0.0F, 0.0F, 0.0F, 3, 6, 5, 0.0F);
        this.setRotateAngle(leg2, -0.40980330836826856F, 1.593485607070823F, -0.045553093477052F);
        this.shape8_6 = new ModelRenderer(this, 0, 27);
        this.shape8_6.setRotationPoint(0.0F, 5.0F, 0.0F);
        this.shape8_6.addBox(0.0F, 0.0F, 0.0F, 3, 6, 4, 0.0F);
        this.setRotateAngle(shape8_6, 0.045553093477052F, 0.0F, 0.0F);
        this.shape1_5 = new ModelRenderer(this, 0, 0);
        this.shape1_5.setRotationPoint(0.0F, 10.0F, 0.0F);
        this.shape1_5.addBox(0.0F, 0.0F, 0.0F, 4, 7, 4, 0.0F);
        this.setRotateAngle(shape1_5, 0.0F, 0.0F, -0.5009094953223726F);
        this.shape8_9 = new ModelRenderer(this, 0, 27);
        this.shape8_9.setRotationPoint(0.0F, 5.0F, 0.0F);
        this.shape8_9.addBox(0.0F, 0.0F, 0.0F, 3, 6, 4, 0.0F);
        this.setRotateAngle(shape8_9, 0.045553093477052F, 0.0F, 0.0F);
        this.shape8_7 = new ModelRenderer(this, 0, 27);
        this.shape8_7.setRotationPoint(0.0F, 4.4F, 0.6F);
        this.shape8_7.addBox(0.0F, -0.4F, 0.0F, 3, 6, 3, 0.0F);
        this.setRotateAngle(shape8_7, -0.045553093477052F, 0.0F, 0.0F);
        this.shape8_11 = new ModelRenderer(this, 0, 82);
        this.shape8_11.setRotationPoint(0.0F, 4.0F, 0.0F);
        this.shape8_11.addBox(0.0F, -0.2F, 0.0F, 3, 2, 5, 0.0F);
        this.setRotateAngle(shape8_11, 0.045553093477052F, 0.0F, 0.0F);
        this.shape8.addChild(this.shape8_1);
        this.shape1.addChild(this.shape1_1);
        this.shape8_1.addChild(this.shape8_2);
        this.shape8_4.addChild(this.shape8_5);
        this.leg2.addChild(this.shape8);
        this.shape24_1.addChild(this.shape28_1);
        this.shape1.addChild(this.leg2_1);
        this.shape1.addChild(this.shape1_2);
        this.shape1_3.addChild(this.shape1_4);
        this.shape8_7.addChild(this.shape8_8);
        this.shape8_3.addChild(this.shape8_4);
        this.shape8_9.addChild(this.shape8_10);
        this.shape24_2.addChild(this.shape24_3);
        this.shape1.addChild(this.shape1_3);
        this.shape24_1.addChild(this.shape28);
        this.leg1.addChild(this.shape8_3);
        this.shape24.addChild(this.shape24_1);
        this.shape1.addChild(this.leg1);
        this.shape1.addChild(this.leg2_2);
        this.shape1_5.addChild(this.shape1_6);
        this.shape24_1.addChild(this.shape24_2);
        this.shape1.addChild(this.shape24);
        this.shape1.addChild(this.leg2);
        this.leg2_1.addChild(this.shape8_6);
        this.shape1_4.addChild(this.shape1_5);
        this.leg2_2.addChild(this.shape8_9);
        this.shape8_6.addChild(this.shape8_7);
        this.shape8_10.addChild(this.shape8_11);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
     	float scaleFactor = 0.5F;
     	GL11.glPushMatrix();
     	GL11.glTranslatef(0F, 1.5F-1.5F*scaleFactor, 0F); 
     	GL11.glScalef(scaleFactor, scaleFactor, scaleFactor);
         this.shape1.render(f5);
         GL11.glPopMatrix();
         }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
    
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn)
    {
        this.leg1.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        this.leg2.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float)Math.PI) * 1.4F * limbSwingAmount;
        this.leg2_1.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float)Math.PI) * 1.4F * limbSwingAmount;
        this.leg2_2.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
    }
    }