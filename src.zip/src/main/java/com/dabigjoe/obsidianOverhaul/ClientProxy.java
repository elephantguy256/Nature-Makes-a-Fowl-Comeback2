package com.dabigjoe.obsidianOverhaul;

import com.dabigjoe.obsidianAPI.file.importer.FileLoader;
import com.dabigjoe.obsidianOverhaul.entity.saiga.EntityGuineaPig;
import com.dabigjoe.obsidianOverhaul.entity.saiga.ModelGuineaPig;
import com.dabigjoe.obsidianOverhaul.entity.saiga.RenderGuineaPig;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy
{	
	private ResourceLocation saigaModelRL = new ResourceLocation("nmfc:models/guineapigamerican.obm");
	private ResourceLocation saigaTextureRL = new ResourceLocation("nmfc:models/guineapig.png");
	
	public void registerRendering()
	{
		 ModelGuineaPig modelSaiga = FileLoader.loadModelFromResources("saiga", saigaModelRL, saigaTextureRL, ModelGuineaPig.class);
	        modelSaiga.setModelScale(0.4F);
	        RenderGuineaPig saigaRenderer = new RenderGuineaPig(modelSaiga);
	        RenderingRegistry.registerEntityRenderingHandler(EntityGuineaPig.class, saigaRenderer);
	}
}
