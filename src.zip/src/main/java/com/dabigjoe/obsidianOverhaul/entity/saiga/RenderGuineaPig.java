package com.dabigjoe.obsidianOverhaul.entity.saiga;

import com.dabigjoe.obsidianAPI.render.RenderAnimated;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderGuineaPig extends RenderAnimated
{
    private static final ResourceLocation BLACK_OCELOT_TEXTURES = new ResourceLocation("nmfc:models/guineapig.png");
    private static final ResourceLocation OCELOT_TEXTURES = new ResourceLocation("nmfc:models/guineapig1.png");
    private static final ResourceLocation RED_OCELOT_TEXTURES = new ResourceLocation("nmfc:models/guineapig.png");
    private static final ResourceLocation SIAMESE_OCELOT_TEXTURES = new ResourceLocation("nmfc:models/guineapig1.png");

    public RenderGuineaPig(ModelGuineaPig saiga)
	{
		super(saiga, 0.8F);
	}

    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation getEntityTexture(EntityGuineaPig entity)
    {
        switch (entity.getTameSkin())
        {
            case 0:
            default:
                return OCELOT_TEXTURES;
            case 1:
                return BLACK_OCELOT_TEXTURES;
            case 2:
                return RED_OCELOT_TEXTURES;
            case 3:
                return SIAMESE_OCELOT_TEXTURES;
        }
    }
}