package com.dabigjoe.obsidianOverhaul;

import com.dabigjoe.obsidianAPI.ObsidianAPIUtil;
import com.dabigjoe.obsidianAPI.animation.wrapper.AIAnimationWrapper;
import com.dabigjoe.obsidianAPI.animation.wrapper.FunctionAnimationWrapper.IsActiveFunction;
import com.dabigjoe.obsidianAPI.registry.AnimationRegistry;
import com.dabigjoe.obsidianOverhaul.entity.ai.EntityAIEat;
import com.dabigjoe.obsidianOverhaul.entity.ai.EntityAIPanicAnimation;
import com.dabigjoe.obsidianOverhaul.entity.saiga.EntityGuineaPig;

import net.minecraft.util.ResourceLocation;

public class CommonProxy
{	
	public void init() 
	{	
		ModEntities.registerEntities();
		registerRendering();
	}

	public void registerRendering() {}

	public void registerAnimations() 
	{
		AnimationRegistry.init();
		
		IsActiveFunction isWalking = (entity) -> { 
			return ObsidianAPIUtil.isEntityMoving(entity) && !entity.isSprinting() && !entity.isSneaking() && entity.onGround;
		};
		IsActiveFunction returnTrue = (entity) -> { 
			return true;
		};
		IsActiveFunction isCalling = (entity) -> { 
			return entity instanceof EntityGuineaPig ? ((EntityGuineaPig) entity).isCalling() : false;
			};
			
			AnimationRegistry.registerEntity(EntityGuineaPig.class, "guineapig");
			AnimationRegistry.registerAnimation("guineapig", "Walk", new ResourceLocation("nmfc:animations/guineapig/guineapigwalk.oba"), 10, true, isWalking);
			AnimationRegistry.registerAnimation("guineapig", "Eat", new AIAnimationWrapper(EntityAIEat.name, new ResourceLocation("nmfc:animations/guineapig/guineapigidle.oba"), 50, true, 0.5F));
			AnimationRegistry.registerAnimation("guineapig", "Panic", new AIAnimationWrapper(EntityAIPanicAnimation.name, new ResourceLocation("nmfc:animations/guineapig/guineapigwalk.oba"), 0, true));
			AnimationRegistry.registerAnimation("guineapig", "Call", new ResourceLocation("nmfc:animations/guineapig/guineapigpopcorning.oba"), 70, false, isCalling);
			AnimationRegistry.registerAnimation("guineapig", "Idle", new ResourceLocation("nmfc:animations/guineapig/guineapigidle.oba"), 100, true, returnTrue);

		}

	}
